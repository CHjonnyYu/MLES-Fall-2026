
"""Reviewed Week10 replay program. Frozen files in, aligned comparison out."""
import argparse,csv,json,hashlib,os,platform
from pathlib import Path
import numpy as np
import sklearn
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.dummy import DummyRegressor
PAYLOAD={'frozen.csv','split.json','config.json','reference-predictions.csv','replay.py','result.json'}
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read_contract(root,config):
    root=Path(root)
    with (root/'frozen.csv').open(newline='',encoding='utf-8') as f:
        reader=csv.DictReader(f)
        if reader.fieldnames!=['row_id',*config['features'],'target']:raise ValueError('schema: exact column order required')
        rows=list(reader)
    if len(rows)!=config['row_count']:raise ValueError('schema: row count')
    if any(None in r or any(v is None for v in r.values()) for r in rows):raise ValueError('schema: row width')
    ids=[r['row_id'] for r in rows]
    if any(not i.strip() for i in ids):raise ValueError('schema: empty row ID')
    if len(set(ids))!=len(ids):raise ValueError('schema: duplicate row ID')
    values=np.array([[float(r[k]) for k in [*config['features'],'target']] for r in rows])
    if not np.isfinite(values).all():raise ValueError('schema: non-finite numeric value')
    splits=json.loads((root/'split.json').read_text())
    if set(splits)!={'train','validation','test'}:raise ValueError('schema: split names')
    if not all(isinstance(v,list) and all(isinstance(i,str) for i in v) for v in splits.values()):raise ValueError('schema: ID lists required')
    flat=sum(splits.values(),[])
    if len(flat)!=len(set(flat)) or set(flat)!=set(ids):raise ValueError('schema: split overlap or missing IDs')
    if {k:len(v) for k,v in splits.items()}!=config['split_counts']:raise ValueError('schema: split counts')
    lookup={r['row_id']:r for r in rows}
    def cohort(name):
        subset=[lookup[i] for i in splits[name]]
        return np.array([[float(r[k]) for k in config['features']] for r in subset]),np.array([float(r['target']) for r in subset])
    return cohort,splits

def run(root,out):
    root=Path(root).resolve();manifest=json.loads((root/'manifest.json').read_text())
    if manifest.get('format')!='MLES-W10-v2' or set(manifest['sha256'])!=PAYLOAD:raise ValueError('manifest: exact required file list and format')
    for name,value in manifest['sha256'].items():
        if digest(root/name)!=value:raise ValueError('checksum mismatch: '+name)
    config=json.loads((root/'config.json').read_text());cohort,splits=read_contract(root,config)
    Xtr,ytr=cohort('train');Xte,yte=cohort('test')
    chosen=config['selected'];allowed=['median','ridge-1','ridge-20','ridge-100']
    if config['candidate_order']!=allowed or chosen not in allowed:raise ValueError('config: undeclared candidate')
    # The runner itself reads and validates reference predictions; no notebook globals are needed.
    with (root/'reference-predictions.csv').open(newline='',encoding='utf-8') as f:
        reader=csv.DictReader(f)
        if reader.fieldnames!=['row_id','observed','predicted']:raise ValueError('reference: exact header required')
        reference=list(reader)
    if any(None in r or any(v is None for v in r.values()) for r in reference):raise ValueError('reference: row width')
    if [r['row_id'] for r in reference]!=splits['test']:raise ValueError('reference: test ID sequence mismatch')
    ref_y=np.array([float(r['observed']) for r in reference]);ref_p=np.array([float(r['predicted']) for r in reference])
    if not np.isfinite(ref_y).all() or not np.isfinite(ref_p).all():raise ValueError('reference: non-finite value')
    np.testing.assert_array_equal(ref_y,yte)
    model=DummyRegressor(strategy='median') if chosen=='median' else make_pipeline(StandardScaler(),Ridge(alpha=float(chosen.split('-')[1]),solver='svd'))
    model.fit(Xtr,ytr);pred=model.predict(Xte)
    np.testing.assert_allclose(pred,ref_p,atol=config['atol'],rtol=config['rtol'])
    error=pred-yte;delta=pred-ref_p
    result={'selected':chosen,'data_sha256':digest(root/'frozen.csv'),'test_ids':splits['test'],'predictions':pred.tolist(),
        'metrics':{'n':len(yte),'MAE':float(np.abs(error).mean()),'RMSE':float(np.sqrt((error**2).mean()))},
        'reference_comparison_passed':True,'max_reference_difference':float(np.max(np.abs(delta))),
        'process_id':os.getpid(),'working_directory_name':Path.cwd().name,
        'environment':{'python':platform.python_version(),'numpy':np.__version__,'scikit_learn':sklearn.__version__},
        'scope':'Fresh interpreter and working directory, same installed environment; not independent scientific replication'}
    Path(out).write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({'selected':chosen,'test_n':len(yte),'reference_comparison_passed':True}))
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();run(a.root,a.out)

