import argparse,csv,json,hashlib
from pathlib import Path
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.dummy import DummyRegressor
from sklearn.metrics import mean_absolute_error,mean_squared_error

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read_contract(root,config):
    with (root/'frozen.csv').open(newline='',encoding='utf-8') as f:
        reader=csv.DictReader(f)
        if reader.fieldnames!=['row_id',*config['features'],'target']:raise ValueError('schema: exact column order required')
        rows=list(reader)
    if len(rows)!=config['row_count']:raise ValueError('schema: row count')
    if any(None in r or any(v is None for v in r.values()) for r in rows):raise ValueError('schema: row width')
    ids=[r['row_id'] for r in rows]
    if any(not i.strip() for i in ids):raise ValueError('schema: empty row ID')
    if len(set(ids))!=len(ids):raise ValueError('schema: duplicate row ID')
    values=np.array([[float(r[k]) for k in [*config['features'],'target']] for r in rows])
    if not np.isfinite(values).all():raise ValueError('schema: non-finite numeric value')
    splits=json.loads((root/'split.json').read_text())
    if set(splits)!={'train','validation','test'}:raise ValueError('schema: split names')
    flat=sum(splits.values(),[])
    if len(flat)!=len(set(flat)) or set(flat)!=set(ids):raise ValueError('schema: split overlap or missing IDs')
    if {k:len(v) for k,v in splits.items()}!=config['split_counts']:raise ValueError('schema: split counts')
    lookup={r['row_id']:r for r in rows}
    def cohort(name):
        subset=[lookup[i] for i in splits[name]]
        return np.array([[float(r[k]) for k in config['features']] for r in subset]),np.array([float(r['target']) for r in subset])
    return cohort,splits

def run(root,out):
    root=Path(root).resolve()
    manifest=json.loads((root/'manifest.json').read_text())
    expected={'frozen.csv','split.json','config.json','reference-predictions.csv','replay.py','result.json'}
    if set(manifest['sha256'])!=expected:raise ValueError('manifest: required file list')
    for name,value in manifest['sha256'].items():
        if digest(root/name)!=value:raise ValueError('checksum mismatch: '+name)
    config=json.loads((root/'config.json').read_text())
    cohort,splits=read_contract(root,config)
    Xtr,ytr=cohort('train');Xte,yte=cohort('test')
    chosen=config['selected']
    if chosen not in config['candidate_order']:raise ValueError('config: undeclared selected candidate')
    model=DummyRegressor(strategy='median') if chosen=='median' else make_pipeline(StandardScaler(),Ridge(alpha=float(chosen.split('-')[1]),solver='svd'))
    model.fit(Xtr,ytr);pred=model.predict(Xte)
    result={'selected':chosen,'data_sha256':digest(root/'frozen.csv'),'test_ids':splits['test'],'predictions':pred.tolist(),
       'metrics':{'n':len(yte),'MAE':float(mean_absolute_error(yte,pred)),'RMSE':float(np.sqrt(mean_squared_error(yte,pred)))}}
    Path(out).write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({'selected':chosen,'test_n':len(yte),'output_written':True}))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();run(a.root,a.out)
