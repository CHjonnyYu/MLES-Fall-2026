Machine Learning in Engineering Science Fall 2026
Midterm Mock practice

The exam includes six written questions, three answer sheets and two oral practice cases. The separate worked-solutions document includes calculations, point allocation and oral response examples.

Written practice:75 minutes,100 raw points. Oral practice:two minutes. One A4 sheet handwritten on both sides and a standard calculator;no internet,AI or code execution during a timed attempt.

Scope:Weeks1-10 core;Question6 follows the Week10 lesson on 9 November. Optional challenges and later Agent implementation are excluded.

This ungraded Mock is practice,not the formal exam. The midterm on 16 November consists of written and oral examinations only,with no midterm project.

All cases are synthetic teaching examples. Attempt the paper before opening the solutions.
